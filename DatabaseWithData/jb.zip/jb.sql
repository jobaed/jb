-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 11, 2023 at 07:37 AM
-- Server version: 5.7.33
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jb`
--

-- --------------------------------------------------------

--
-- Table structure for table `abouts`
--

CREATE TABLE `abouts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `abouts`
--

INSERT INTO `abouts` (`id`, `title`, `details`, `created_at`, `updated_at`) VALUES
(1, 'My name is Start Bootstrap and I help brands grow.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugit dolorum itaque qui unde quisquam consequatur autem. Eveniet quasi nobis aliquid cumque officiis sed rem iure ipsa! Praesentium ratione atque dolorem?', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `short_des` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumb` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `title`, `user_id`, `short_des`, `thumb`, `created_at`, `updated_at`) VALUES
(3, 'Native type declarations in Laravel 10 skeleton', 1, 'Types are being added in a way that brings the latest PHP type-hinting features to Laravel projects without breaking backward compatibility at the framework level....', 'https://i.ibb.co/NtCXC6z/blog-Banner.webp', '2023-07-01 19:19:17', NULL),
(4, 'Speak Out Against Bills That Threaten End-to-End Encryption', 2, 'When the U.S. Supreme Court overturned Roe v. Wade in 2022, Americans lost their constitutional right to an abortion. Suddenly, law enforcement could use private conversations, period tracking app data...', 'https://i.ibb.co/ZLKymp0/Dont-Walk-Image-1536x933.jpg', '2023-07-01 19:19:21', NULL),
(5, 'Encryption Keeps Kids Safe Online', 3, 'As parents and Internet advocates, we’re passionate about children’s safety online, and we do everything in our power to keep our kids safe. Just as we buckle them into seatbelts and make regular doctors visits...', 'https://i.ibb.co/4sPLn9y/girl-using-laptop.jpg', '2023-07-09 19:24:43', NULL),
(6, 'The Real Impact of Internet Shutdowns', 2, 'Earlier this month, people in Algeria might have felt like they’d woken up in a different era as they struggled to conduct their daily online lives. The government had ordered Internet Service Providers (ISPs) to block certain websites...', 'https://i.ibb.co/GVzbYv9/towfiqu-barbhuiya-jpqyf-K7-GB4w-unsplash-min.jpg', '2023-07-11 19:24:50', NULL),
(7, 'Meta is finally having its moment with the Twitter alternative Threads', 1, 'With 100 million users, Mark Zuckerberg is already winning his fight against Elon Musk — at least in the cage match that is social media.', 'https://i.ibb.co/0m8n8qV/Getty-Images-1513216836-0.webp', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `blog_details`
--

CREATE TABLE `blog_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `blog_id` bigint(20) UNSIGNED NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `tag_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog_details`
--

INSERT INTO `blog_details` (`id`, `blog_id`, `content`, `tag_name`, `created_at`, `updated_at`) VALUES
(1, 4, 'Three Bills Before Congress Could Break Encryption\r\nBut there are three bills before the United States Congress that threaten encryption, the strongest tool we have for keeping every user of the Internet safe. Policymakers want to curb the online spread of illegal content and protect children through measures that would force them to remove or weaken end-to-end encryption.\r\n\r\nEveryone, including children, deserves protection from exploitation online. But forcing companies to bypass or weaken encryption is misguided and will only leave us all more vulnerable.  \r\n\r\nWhat is End-to-End Encryption?\r\nEnd-to-end encryption is any form of encryption in which only the sender and intended recipient can read the message. No third party, even the party providing the communication service, has a key to access the communication. End-to-end encryption is the most secure form of encryption that you can use.\r\n\r\nThree Ways Encryption Safeguards Kids\r\nIf policymakers want to protect kids online, encryption can help. Like us, children live in a digital world, and use online communications platforms to do schoolwork, play games, make art, and chat with their friends. Our job is to keep all kids safe online. Here are three ways encryption does that:\r\n\r\nIt keeps private family photos stored on encrypted cloud accounts safe and secure.\r\nIt prevents strangers from listening in or seeing messages sent by a child to their friends on messaging apps.\r\nIt keeps message content private so it can’t be scanned for ad profiling and targeted with inappropriate content.\r\nWhat’s At Risk if Encryption is Broken\r\nWhen we remove encryption from online communication platforms, we opens ourselves up to risks that we usually can’t see in the moment and can’t prevent until it’s too late.\r\n\r\nMany families have harmless photos of their children in the bath stored on a cloud account. Without encryption, these photos could be more easily stolen, altered, and shared as child sexual abuse material on the Internet.\r\nDomestic violence hotlines often use WhatsApp, which is end-to-end encrypted. Without encryption, messages to people who need help may not be private from abusers.\r\nWithout encryption, LGBTQ+ people could have their private conversations exposed and used against them—opening them up to blackmail, violence, and death.\r\nWhen end-to-end encrypted communications are undermined, it puts our national security at greater risk by making sensitive information more vulnerable to interception.\r\nCompanies rely on end-to-end encryption to protect trade secrets. Without it, they’ll be vulnerable to corporate espionage, including from competitors overseas.', 'Tech', '2023-07-10 19:19:05', NULL),
(2, 3, 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quas provident omnis magnam iure harum similique blanditiis beatae, autem officia veniam. Odit cumque facilis officiis? Sapiente odit ea maiores eos incidunt.lore Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tenetur recusandae vero, quasi laboriosam ipsum harum neque mollitia placeat, deleniti cupiditate molestiae sunt sit, ratione animi quae expedita a repudiandae architecto? Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quod expedita blanditiis facere. Officiis quis itaque voluptates delectus necessitatibus quas, a ea impedit, aut laudantium dignissimos fugit quasi adipisci eaque exercitationem!Dolores, nostrum qui cum voluptatem vel aspernatur voluptate molestiae aut, aperiam, dignissimos nihil! Similique ex repudiandae nostrum odio fugiat. Facilis earum voluptate temporibus eveniet pariatur id excepturi rem laudantium. Tempore! Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita corporis cum debitis minus, est illum corrupti sapiente dignissimos, cupiditate sit porro? Maxime iusto vitae culpa quas et nulla voluptatem corporis.Perferendis provident odio consequatur error tempore dicta, quia cum adipisci harum rerum soluta laborum aliquam sapiente vitae quam modi recusandae quod quos ipsum? Optio, nam esse? Blanditiis accusamus quibusdam debitis.\r\n\r\n\r\nLorem ipsum dolor sit, amet consectetur adipisicing elit. Quas provident omnis magnam iure harum similique blanditiis beatae, autem officia veniam. Odit cumque facilis officiis? Sapiente odit ea maiores eos incidunt. Lorem ipsum, dolor sit amet consectetur adipisicing elit. Impedit nobis inventore eveniet nihil! Neque adipisci, totam doloribus repudiandae recusandae facere quo ea saepe repellat a provident facilis. Numquam, officiis recusandae? Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis cumque, libero quisquam voluptatibus dolor odio aut in quo a, illum dolorem reprehenderit architecto quia repellendus nesciunt? Ipsam magni fugiat minima!\r\n\r\n\r\nLorem ipsum dolor sit, amet consectetur adipisicing elit. Quas provident omnis magnam iure harum similique blanditiis beatae, autem officia veniam. Odit cumque facilis officiis? Sapiente odit ea maiores eos incidunt. Lorem ipsum, dolor sit amet consectetur adipisicing elit. Impedit nobis inventore eveniet nihil! Neque adipisci, totam doloribus repudiandae recusandae facere quo ea saepe repellat a provident facilis. Numquam, officiis recusandae?\r\n\r\n\r\nLorem ipsum dolor sit, amet consectetur adipisicing elit. Quas provident omnis magnam iure harum similique blanditiis beatae, autem officia veniam. Odit cumque facilis officiis? Sapiente odit ea maiores eos incidunt.lore Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tenetur recusandae vero, quasi laboriosam ipsum harum neque mollitia placeat, deleniti cupiditate molestiae sunt sit, ratione animi quae expedita a repudiandae architecto?', 'Travels', '2023-07-09 19:19:11', NULL),
(3, 5, 'As parents and Internet advocates, we’re passionate about children’s safety online, and we do everything in our power to keep our kids safe. Just as we buckle them into seatbelts and make regular doctors visits, we keep tabs on what they’re doing online, using tools like encryption to protect them from danger.\r\n\r\nThat’s why we’re so worried about proposals like the EARN IT Act, the STOP CSAM Act, and the Kids Online Safety Act in the U.S. These proposals erode the best tool we have for keeping our kids’ information—like where they live and go to school—private and secure.\r\n\r\nAllowing our kids to have an online life isn’t always easy. Being a parent is finding the balance between hovering and giving our children independence. Thankfully, there’s a middle ground. We can take control of some of the unknowns, so that we can reduce online risks. By turning to tools and actions, we can ensure our kids aren’t exposed to inappropriate content or contacted by strangers. Encryption is key to this, empowering us so our children can have a healthy, safe online presence—one in which their information isn’t exposed.\r\n\r\nHow Do These Proposals Put Kids at Risk?\r\nThese proposals eat away at encryption. They take away our ability to use the tool that’s vital to keeping our own kids safe online.\r\n\r\nBoth the EARN IT Act and the STOP CSAM Act would give power to courts to consider the use of encryption as proof of liability in cases of child sexual abuse material (CSAM) distribution on a platform. While the EARN IT Act introduces criminal charges for platforms, the STOP CSAM Act introduces sweeping civil liability for platforms and infrastructure providers. In both cases, the end result is undermined encryption.\r\n\r\nEARN IT and STOP CSAM would put platforms at risk of liability for delivering illegal traffic, despite potentially having no knowledge of its contents. This would discourage companies from making encryption available on their services, or even allowing customers to use encrypted services.\r\n\r\nKids Online Safety Act (KOSA) would also force platforms to choose between using end-to-end encryption or weakening it to filter content.\r\n\r\nAs parents, the endless potential outcomes are horrifying. The irony is that many of us don’t realize how much we depend on encryption—because it thrums along silently, preventing worst-case scenarios.', 'Encryption', NULL, NULL),
(4, 6, 'Economic Impact on Local Citizens\r\nMehdi Dahhak, a journalist and director of Desert Foot, told Internet Society partner Social Media Exchange (SMEX), “This reality disrupts our work significantly, especially since most of our readers are Facebook and Twitter users, which leads to a decrease in readability rates and this affects us economically.”\r\n\r\nSarah Zahaf, a manager at a tourism agency in Algiers, also told SMEX that tourism businesses are among the biggest losers due to the interruption of Internet access. “[The Internet disruptions] hindered our communication with our customers outside the country, and our agency suffered material losses estimated at 10% per day due to [missing] ticket reservation [deadlines], in addition to our inability to meet the requests of customers arriving due to the interruption of the network.”\r\n\r\nMeasuring the economic impact of Internet shutdowns like the ones that happened in Algeria, as well as the other 18 shutdowns that Internet Society Pulse has tracked in the month of June alone, has been a challenge outside of these personal accounts. Until now.\r\n\r\nIntroducing the NetLoss Calculator\r\nThe  NetLoss calculator is a new tool that estimates the economic cost of Internet shutdowns by way of a rigorous methodology.\r\n\r\nStart Calculating\r\nThe NetLoss calculator uses a reproducible, econometric framework to consider a wide range of publicly available economic inputs including:\r\n\r\nShutdown data: Internet Society Pulse provides detailed event-level data on government-mandated shutdown events and classifies shutdowns since 2019 as either national or regional shutdowns or service blocking.\r\nProtests and civil unrest: The Armed Conflict Location & Event Data Project provides detailed event-level data on various events since 2016. Each event is classified as belonging to one of five types: (a) battles; (b) protests; (c) riots; (d) strategic developments; or (e) violence against civilians. It also logs the start and end dates for these events and provides details of who the involved parties were and if there were any fatalities associated with the event.\r\nElections: The Constituency-Level Elections Archive maintained by Yale University provides data from elections to the lower chambers for more than 150 countries at the month-year level since 1960.\r\nSocioeconomic indicators: World Bank provides data on economic indicators (GDP in USD purchasing-power-parity terms, at current prices), employment (International Labor Organization (ILO) estimates), and Foreign Direct Investment (FDI, as a percentage of GDP as well as net inflows).', 'Currency', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `blog_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `comment`, `blog_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'The article covers the essentials, challenges, myths and stages the UX designer should consider while creating the design strategy.', 5, 1, '2023-07-10 19:31:49', NULL),
(2, 'Very straight-to-point article. Really worth time reading. Thank you! But tools are just the instruments for the UX designers. The knowledge of the design tools are as important as the creation of the design strategy.', 5, 2, '2023-07-09 19:31:54', NULL),
(3, 'Thanks for sharing this. I do came from the Backend development and explored some of the tools to design my Side Projects.', 3, 3, '2023-07-09 19:31:56', NULL),
(4, 'Very straight-to-point article. Really worth time reading. Thank you! But tools are just the instruments for the UX designers. The knowledge of the design tools are as important as the creation of the design strategy.', 3, 2, '2023-07-01 19:31:58', NULL),
(5, 'Thanks for sharing this. I do came from the Backend development and explored some of the tools to design my Side Projects.', 4, 1, '2023-06-30 19:32:01', NULL),
(6, 'The article covers the essentials, challenges, myths and stages the UX designer should consider while creating the design strategy.', 4, 2, '2023-07-11 19:32:04', NULL),
(7, 'Very straight-to-point article. Really worth time reading. Thank you! But tools are just the instruments for the UX designers. The knowledge of the design tools are as important as the creation of the design strategy.', 6, 2, '2023-07-02 19:32:06', NULL),
(8, 'The article covers the essentials, challenges, myths and stages the UX designer should consider while creating the design strategy.', 6, 3, '2023-07-05 19:32:11', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `fullName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `educations`
--

CREATE TABLE `educations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `duration` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instituteName` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `educations`
--

INSERT INTO `educations` (`id`, `duration`, `instituteName`, `field`, `details`, `created_at`, `updated_at`) VALUES
(1, '2012 - 2017', 'Hazi Abul Fazal High school, Pardiakul, Katiadi', 'Secondary School Certificate', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus laudantium, voluptatem quis repellendus eaque sit animi illo ipsam amet officiis corporis sed aliquam non voluptate corrupti excepturi maxime porro fuga.', NULL, NULL),
(2, '2017 - 2021', 'Brahmanbaria Polytechnic Institute , Brahmanbaria', 'Diploma In Computer Science', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus laudantium, voluptatem quis repellendus eaque sit animi illo ipsam amet officiis corporis sed aliquam non voluptate corrupti excepturi maxime porro fuga.', NULL, NULL),
(3, '2021 - 2022', 'IT Bangladesh, Mirpur, Dhaka', 'Web Design & Development (PHP)', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus laudantium, voluptatem quis repellendus eaque sit animi illo ipsam amet officiis corporis sed aliquam non voluptate corrupti excepturi maxime porro fuga.', NULL, NULL),
(4, '2022 - Present', 'Ostad', 'Web Development with PHP & Laravel', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus laudantium, voluptatem quis repellendus eaque sit animi illo ipsam amet officiis corporis sed aliquam non voluptate corrupti excepturi maxime porro fuga.', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `experences`
--

CREATE TABLE `experences` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `duration` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `experences`
--

INSERT INTO `experences` (`id`, `duration`, `title`, `designation`, `details`, `created_at`, `updated_at`) VALUES
(1, '2019 - Present', 'Web Developer', 'Stark Industries\r\nLos Angeles, CA', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus laudantium, voluptatem quis repellendus eaque sit animi illo ipsam amet officiis corporis sed aliquam non voluptate corrupti excepturi maxime porro fuga.', NULL, NULL),
(2, '2017 - 2019', 'SEM Specialist', 'Wayne Enterprises\r\nGotham City, NY', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus laudantium, voluptatem quis repellendus eaque sit animi illo ipsam amet officiis corporis sed aliquam non voluptate corrupti excepturi maxime porro fuga.', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `heroproperties`
--

CREATE TABLE `heroproperties` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `keyLine` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `heroproperties`
--

INSERT INTO `heroproperties` (`id`, `keyLine`, `title`, `short_title`, `img`, `created_at`, `updated_at`) VALUES
(1, 'DESIGN · DEVELOPMENT · MARKETING', 'I can help your business to', 'Get online and grow fast', 'https://i.ibb.co/CQ9ccPh/2.png', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'HTML', NULL, NULL),
(2, 'CSS', NULL, NULL),
(3, 'JavaScript', NULL, NULL),
(4, 'Python', NULL, NULL),
(5, 'Ruby', NULL, NULL),
(6, 'Node.js', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(2, '2023_06_21_170256_create_contacts', 1),
(3, '2023_06_21_170558_create_seoproperties', 1),
(4, '2023_06_21_170954_create_heroproperties', 1),
(5, '2023_06_21_171135_create_experences', 1),
(6, '2023_06_21_171805_create_resumes', 1),
(7, '2023_06_21_171901_create_projects', 1),
(8, '2023_06_21_172038_create_skills', 1),
(9, '2023_06_21_172135_create_languages', 1),
(10, '2023_06_23_100826_create_abouts', 2),
(11, '2023_06_23_100903_create_educations', 2),
(12, '2023_06_23_100958_create_socials', 2),
(13, '2023_07_09_185853_create_blogs_table', 3),
(14, '2023_07_09_191307_create_blogs_table', 4),
(15, '2023_07_09_191431_create_blog_details_table', 4),
(16, '2023_07_10_184320_create_users_table', 5),
(17, '2023_07_10_184902_create_comments_table', 6),
(18, '2023_07_10_184457_create_blogs_table', 7),
(19, '2023_07_10_184542_create_blog_details_table', 7),
(20, '2023_07_10_192844_create_comments_table', 8);

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `previewLink` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumbnailLink` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `title`, `previewLink`, `thumbnailLink`, `details`, `created_at`, `updated_at`) VALUES
(1, 'karigorc | Interior ', 'https://karigorci.com/', 'https://i.ibb.co/sbKbS4K/karigorci.png', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius at enim eum illum aperiam placeat esse? Mollitia omnis minima saepe recusandae libero, iste ad asperiores! Explicabo commodi quo itaque! Ipsam!', NULL, NULL),
(2, 'IT Bangladesh | Trainings Institute ', 'https://itbd.tech/', 'https://i.ibb.co/PW8dt1W/itbdfibnal.png', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius at enim eum illum aperiam placeat esse? Mollitia omnis minima saepe recusandae libero, iste ad asperiores! Explicabo commodi quo itaque! Ipsam!', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `resumes`
--

CREATE TABLE `resumes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `downloadLink` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `resumes`
--

INSERT INTO `resumes` (`id`, `downloadLink`, `created_at`, `updated_at`) VALUES
(1, 'https://drive.google.com/file/d/1zT5-hO4tp45Ml5ZveqKLVPt038VBajD0/view?usp=sharing', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `seoproperties`
--

CREATE TABLE `seoproperties` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `pageName` enum('home','resume','project','contact') COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ogSiteName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ogUrl` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ogTitle` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ogDescription` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ogImage` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE `skills` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'SEO/SEM Marketing', NULL, NULL),
(2, 'Statistical Analysis', NULL, NULL),
(3, 'Web Development', NULL, NULL),
(4, 'Network Security', NULL, NULL),
(5, 'Adobe Software Suite', NULL, NULL),
(6, 'User Interface Design', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `socials`
--

CREATE TABLE `socials` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `twitterLink` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `githubLink` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `linkedinLink` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `socials`
--

INSERT INTO `socials` (`id`, `twitterLink`, `githubLink`, `linkedinLink`, `created_at`, `updated_at`) VALUES
(1, 'scc.li/dmplv', 'https://github.com/jobaed', 'https://www.linkedin.com/in/jobaed-bhuiyan-356153177/', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `profile`, `created_at`, `updated_at`) VALUES
(1, 'Jobard Bhuiyan', 'jobaedbhuiyan34@gmail.com', 'https://i.ibb.co/SJNwPdZ/2.png', '2023-06-01 04:55:14', NULL),
(2, 'JB', 'jb@gmail.com', 'https://i.ibb.co/XYfxM4G/300X300.png', '2023-06-02 04:55:25', NULL),
(3, 'Admin', 'admin@gmail.com', 'https://i.ibb.co/mB0842G/Avatar.jpg', '2023-06-15 04:55:30', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `abouts`
--
ALTER TABLE `abouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `blogs_user_id_foreign` (`user_id`);

--
-- Indexes for table `blog_details`
--
ALTER TABLE `blog_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `blog_details_blog_id_unique` (`blog_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comments_blog_id_foreign` (`blog_id`),
  ADD KEY `comments_user_id_foreign` (`user_id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `educations`
--
ALTER TABLE `educations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `experences`
--
ALTER TABLE `experences`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `heroproperties`
--
ALTER TABLE `heroproperties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `resumes`
--
ALTER TABLE `resumes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seoproperties`
--
ALTER TABLE `seoproperties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skills`
--
ALTER TABLE `skills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `socials`
--
ALTER TABLE `socials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `abouts`
--
ALTER TABLE `abouts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `blog_details`
--
ALTER TABLE `blog_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `educations`
--
ALTER TABLE `educations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `experences`
--
ALTER TABLE `experences`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `heroproperties`
--
ALTER TABLE `heroproperties`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `resumes`
--
ALTER TABLE `resumes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `seoproperties`
--
ALTER TABLE `seoproperties`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `skills`
--
ALTER TABLE `skills`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `socials`
--
ALTER TABLE `socials`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `blogs`
--
ALTER TABLE `blogs`
  ADD CONSTRAINT `blogs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `blog_details`
--
ALTER TABLE `blog_details`
  ADD CONSTRAINT `blog_details_blog_id_foreign` FOREIGN KEY (`blog_id`) REFERENCES `blogs` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_blog_id_foreign` FOREIGN KEY (`blog_id`) REFERENCES `blogs` (`id`),
  ADD CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
